# Nutanix BGP Gateway Placement Audit

Read-only Ansible + Python toolkit to inventory BGP Gateway VM placement across
the fleet, and flag every cluster/VPC where both gateways in a pair are
currently on the same AHV host — the anti-affinity gap covered in
`adr-bgp-gateway-anti-affinity.md`.

## What this does

1. Ansible connects to one CVM per cluster (never writes anything) and runs
   read-only `acli`/`ncli` discovery commands.
2. Raw output is saved per cluster to `reports/raw/`.
3. A Python script parses that raw output, pairs gateway VMs to VPCs, and
   cross-references current host placement.
4. Output: a master CSV inventory and a Markdown summary flagging every
   cluster/VPC that needs the anti-affinity redesign.

## What this does NOT do

- No configuration changes, no VM moves, no policy changes. Every remote
  command is a read-only `list` / `get` / `info` call.
- Does not itself create the anti-affinity policy — this is the audit that
  tells you where to apply it.

## Prerequisites

- Ansible >= 2.15, Python >= 3.9 on the control node. `pip install pyyaml`
  if you plan to use manual VPC overrides (see below).
- SSH reachability from the control node to one CVM per cluster — ideally
  the cluster's virtual/data-services IP rather than a single CVM's IP, so
  a CVM reboot on that cluster doesn't break the audit.
- A dedicated, least-privilege SSH account for this automation rather than
  reusing `nutanix`/`admin` interactively. It only ever needs to run
  read-only commands.
- Credentials stored in Ansible Vault, never plaintext in the inventory.

## Setup

1. Copy `inventory/clusters.yml.example` to `inventory/clusters.yml` and add
   one entry per cluster, grouped by site.
2. Copy `group_vars/all.yml.example` to `group_vars/all.yml`, fill in the
   SSH user/key path, then encrypt it:
   ```
   ansible-vault encrypt group_vars/all.yml
   ```
3. Copy `config/gateway_vpc_map.yml.example` to
   `config/gateway_vpc_map.yml` — see "Pairing gateways to VPCs" below.

## Running

**Validate against one cluster first** — don't point this at all 20+ on the
first run:
```
ansible-playbook playbooks/discover_bgp_gateways.yml --ask-vault-pass --limit cluster-sjc-01
```
Open `reports/raw/cluster-sjc-01.json` and confirm the `acli vm.get` output
actually contains a recognizable host field (see "Validation checklist"
below) before running the full fleet.

Full fleet:
```
ansible-playbook playbooks/discover_bgp_gateways.yml --ask-vault-pass
```

Then generate the report:
```
python3 scripts/parse_gateway_placement.py
```
Output lands in `reports/master_inventory.csv` and `reports/summary.md`.

## Identifying gateway VMs

The playbook finds gateway *candidates* by matching VM names against
`gateway_name_pattern` (default: anything containing "bgp", "gw", or
"gateway", case-insensitive). Update that pattern in
`playbooks/discover_bgp_gateways.yml` to match your actual naming
convention before running — the accuracy of the whole audit depends on it.
For clusters where names don't cleanly identify gateways, use an explicit
override instead (next section).

## Pairing gateways to VPCs

Host-level discovery can tell you where a VM is running — it can't tell you
which VPC it belongs to; that mapping lives in Prism Central. The parser
makes a best-effort guess by grouping gateway names that share a common
prefix (e.g., `BGP-GW-A` / `BGP-GW-B` pair automatically). Where that
heuristic doesn't hold, override it explicitly in
`config/gateway_vpc_map.yml`.

## Validation checklist before trusting the output

- [ ] Confirm `acli vm.list` output on your AOS build puts the VM name as
      the first column — candidate-name extraction assumes this.
- [ ] Confirm `acli vm.get <vm>` output contains a host/node identifier
      field. Check `reports/raw/<cluster>.json`; if the field name differs
      from what's in `HOST_FIELD_PATTERNS`, add a pattern in
      `scripts/parse_gateway_placement.py`.
- [ ] Spot-check one cluster's result against what Prism Central shows
      directly before trusting the full-fleet report.

## Recommended follow-up

Prism Central's REST API (v3/v4) is a more authoritative source for
VPC-to-gateway mapping than name-pattern matching, since Network Gateways
are first-class PC-managed objects there. Worth layering in as a
cross-check once you've confirmed the exact endpoint for your PC version
via its API Explorer (`https://<PC>:9440/api_explorer`). This toolkit is
built around host-level SSH discovery specifically because that's what was
asked for — the two sources should agree, and PC's API is the one to trust
if they ever don't.

## Layout

```
.
├── ansible.cfg
├── inventory/clusters.yml.example
├── group_vars/all.yml.example
├── config/gateway_vpc_map.yml.example
├── playbooks/discover_bgp_gateways.yml
├── scripts/parse_gateway_placement.py
└── reports/                # generated — raw/, master_inventory.csv, summary.md
```
