#!/usr/bin/env python3
"""
parse_gateway_placement.py

Reads raw per-cluster discovery output produced by
playbooks/discover_bgp_gateways.yml (reports/raw/<cluster>.json),
pairs gateway VMs to VPCs, cross-references current host placement,
and flags any pair sharing a host as needing the anti-affinity
redesign from adr-bgp-gateway-anti-affinity.md.

Read-only. Makes no changes to any cluster. Safe to re-run.
"""

import json
import re
import sys
import csv
from pathlib import Path
from collections import defaultdict

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "reports" / "raw"
OUT_CSV = BASE_DIR / "reports" / "master_inventory.csv"
OUT_SUMMARY = BASE_DIR / "reports" / "summary.md"
OVERRIDE_FILE = BASE_DIR / "config" / "gateway_vpc_map.yml"

# acli's output format can vary by build. If none of these match what you
# see in reports/raw/<cluster>.json for a given VM, add a pattern here.
HOST_FIELD_PATTERNS = [
    r'host_uuid\s*[:=]\s*"?([a-zA-Z0-9\-\.]+)"?',
    r'node_uuid\s*[:=]\s*"?([a-zA-Z0-9\-\.]+)"?',
    r'host_name\s*[:=]\s*"?([a-zA-Z0-9\-\.]+)"?',
    r'\bnode\s*[:=]\s*"?([a-zA-Z0-9\-\.]+)"?',
]


def load_overrides():
    if not OVERRIDE_FILE.exists():
        return {}
    try:
        import yaml
    except ImportError:
        print(f"WARNING: PyYAML not installed, ignoring {OVERRIDE_FILE}. "
              f"pip install pyyaml to use manual VPC overrides.", file=sys.stderr)
        return {}
    with open(OVERRIDE_FILE) as f:
        data = yaml.safe_load(f) or {}
    return data.get("overrides", {}) or {}


def extract_host(raw_text):
    """Best-effort extraction of a host/node identifier from acli vm.get output."""
    for pattern in HOST_FIELD_PATTERNS:
        match = re.search(pattern, raw_text or "")
        if match:
            return match.group(1)
    return None


def guess_pair_key(name):
    """Strip a trailing -A/-B, -1/-2, -primary/-secondary style suffix so
    gateway names can be grouped into pairs when no override is given."""
    stripped = re.sub(r'[-_]?(a|b|1|2|primary|secondary)$', '', name, flags=re.IGNORECASE)
    return stripped.lower()


def main():
    if not RAW_DIR.exists() or not any(RAW_DIR.glob("*.json")):
        print(f"No raw output found in {RAW_DIR}. Run the Ansible playbook first.",
              file=sys.stderr)
        sys.exit(1)

    overrides = load_overrides()
    rows = []
    warnings = []
    failed_clusters = []

    for raw_file in sorted(RAW_DIR.glob("*.json")):
        cluster = raw_file.stem
        try:
            data = json.loads(raw_file.read_text())
        except json.JSONDecodeError:
            failed_clusters.append((cluster, "unreadable/corrupt raw output"))
            continue

        candidates = data.get("gateway_candidates", [])
        detail_raw = data.get("gateway_detail_raw", [])

        if not candidates:
            warnings.append(
                f"{cluster}: no VM names matched the gateway pattern — "
                f"check gateway_name_pattern in the playbook, or add an "
                f"override in config/gateway_vpc_map.yml.")
            continue

        gw_host = {}
        for name, detail in zip(candidates, detail_raw):
            host = extract_host(detail)
            if host is None:
                warnings.append(
                    f"{cluster}/{name}: could not extract a host field "
                    f"from acli output — update HOST_FIELD_PATTERNS in "
                    f"this script.")
            gw_host[name] = host

        # Build VPC pairing: explicit overrides first, then best-effort
        # name grouping for anything not covered by an override.
        cluster_overrides = overrides.get(cluster, [])
        paired_names = set()
        pairs = []  # (vpc_label, [gw_names])

        for entry in cluster_overrides:
            names = entry.get("gateways", [])
            pairs.append((entry.get("vpc", "unlabeled"), names))
            paired_names.update(names)

        remaining = [n for n in candidates if n not in paired_names]
        grouped = defaultdict(list)
        for name in remaining:
            grouped[guess_pair_key(name)].append(name)
        for key, names in grouped.items():
            pairs.append((f"auto:{key}", names))

        for vpc_label, names in pairs:
            hosts_in_pair = {gw_host.get(n) for n in names}
            hosts_in_pair.discard(None)
            violation = len(names) >= 2 and len(hosts_in_pair) == 1

            for name in names:
                rows.append({
                    "cluster": cluster,
                    "vpc": vpc_label,
                    "gateway_vm": name,
                    "current_host": gw_host.get(name) or "UNKNOWN",
                    "pair_size": len(names),
                    "anti_affinity_violation": "YES" if violation else "no",
                })

    # Write CSV
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["cluster", "vpc", "gateway_vm", "current_host",
                  "pair_size", "anti_affinity_violation"]
    with open(OUT_CSV, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    # Write summary
    violations = [r for r in rows if r["anti_affinity_violation"] == "YES"]
    clusters_scanned = len({r["cluster"] for r in rows})
    violating_clusters = sorted({r["cluster"] for r in violations})

    with open(OUT_SUMMARY, "w") as f:
        f.write("# BGP Gateway Placement Audit — Summary\n\n")
        f.write(f"Clusters scanned: {clusters_scanned}\n\n")
        f.write(f"Gateway VMs inventoried: {len(rows)}\n\n")
        f.write(f"Anti-affinity violations found: {len(violations)}\n\n")

        if violating_clusters:
            f.write("## Clusters requiring redesign\n\n")
            f.write("| Cluster | VPC | Gateway VM | Host |\n")
            f.write("|---|---|---|---|\n")
            for r in violations:
                f.write(f"| {r['cluster']} | {r['vpc']} | {r['gateway_vm']} | {r['current_host']} |\n")
            f.write("\n")
        else:
            f.write("No co-located gateway pairs found in this run.\n\n")

        if failed_clusters:
            f.write("## Clusters that failed to collect\n\n")
            for cluster, reason in failed_clusters:
                f.write(f"- {cluster}: {reason}\n")
            f.write("\n")

        if warnings:
            f.write("## Warnings — review before trusting full results\n\n")
            for w in warnings:
                f.write(f"- {w}\n")

    print(f"Wrote {OUT_CSV}")
    print(f"Wrote {OUT_SUMMARY}")
    if warnings:
        print(f"\n{len(warnings)} warning(s) logged — see {OUT_SUMMARY}", file=sys.stderr)


if __name__ == "__main__":
    main()
